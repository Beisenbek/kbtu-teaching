#include <iostream>
#include <cmath>

using namespace std;

int main(){

	int x;

	cin >> x;

	printf("%.10f\n", sqrt(x));

	return 0;
}
